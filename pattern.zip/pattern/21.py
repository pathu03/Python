


count=1
for i in range(1,6):
    x=""
    for j in range(0,i):
            x=x+" "
            x=x+str(count)
            count+=1
    print(x)
