for i in range(0,5):
    x=""
    for j in range(5,i,-1):
        x=x+str(j)
    print(x)