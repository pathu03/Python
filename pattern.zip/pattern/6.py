for i in range(5,0,-1):
    x=""
    for j in range(i,0,-1):
        x=x+str(j)
    print(x)