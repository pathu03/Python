for i in range(5,0,-1):
    x = ""
    for j in  range(i,6):
        x = x + str(i)
    print(x)