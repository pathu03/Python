for i in range(5,6):
    x = ""
    for j in range(5,0,-1):
            x+=str(j)
            print(x)