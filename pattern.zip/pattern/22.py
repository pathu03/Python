count=('a')
for i in range(1,6):
    x=""
    for j in range(1,i+1):
        x=x+str(count)
    print(x)
