
for i in range(0,5):
    x = ""
    for j in range(i+1,6):
        x= x + str(j)
    print(x)
    