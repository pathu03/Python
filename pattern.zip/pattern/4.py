for i in range(1,6):
    x = ""
    for j in range(i,0,-1):
        x= x + str(j)
    print(x)