for i in range(45,50):
    x = ""
    for j in  range(45,i+1):
        x = x + str(j)
    print(x)