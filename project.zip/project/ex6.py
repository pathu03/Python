x=[[1,2,3],
   [4,5,6],
   [7,8,9]]
sum=0
for i in range(len(x)):
      sum=sum+(x[i][3-1-i])
      print((x[i][3-1-i]))
print(sum)